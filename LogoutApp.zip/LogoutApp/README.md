# SAPUI5_LogoutApp
The project shows how to logout from the custom SAPUI5 application
