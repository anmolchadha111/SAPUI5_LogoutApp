sap.ui.define([
	"com/sap/LogoutApp/test/unit/controller/View1.controller"
], function () {
	"use strict";
});